package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.firebase.FirebaseRealtimeManager
import com.example.data.local.AppDatabase
import com.example.data.local.BannerEntity
import com.example.data.local.GemEntity
import com.example.data.local.NewsDao
import com.example.data.local.NewsPostEntity
import com.example.data.local.SiteSettingsEntity
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.data.model.SiteSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class NewsRepository(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val tag = "NewsRepository"
    private val database = AppDatabase.getInstance(context)
    private val newsDao: NewsDao = database.newsDao()
    val firebaseManager = FirebaseRealtimeManager(context)

    val postsFlow: Flow<List<NewsPost>> = newsDao.getAllPosts().map { entities ->
        entities.map { it.toModel() }
    }.flowOn(Dispatchers.IO)

    val settingsFlow: Flow<SiteSettings> = newsDao.getSettings().map { entity ->
        entity?.toModel() ?: SiteSettings()
    }.flowOn(Dispatchers.IO)

    val bannersFlow: Flow<List<BannerItem>> = newsDao.getAllBanners().map { entities ->
        entities.map { it.toModel() }
    }.flowOn(Dispatchers.IO)

    val gemsFlow: Flow<List<GemItem>> = newsDao.getAllGems().map { entities ->
        entities.map { it.toModel() }
    }.flowOn(Dispatchers.IO)

    val isFirebaseConnected: StateFlow<Boolean> = firebaseManager.isConnected

    init {
        // 1. Seed local database if empty
        scope.launch(Dispatchers.IO) {
            checkAndSeedLocalDatabase()
        }

        // 2. Observe Firebase RTDB posts -> sync to Room
        scope.launch(Dispatchers.IO) {
            firebaseManager.remotePosts.collect { remoteList ->
                if (remoteList != null) {
                    newsDao.deleteAllPosts()
                    newsDao.insertPosts(remoteList.map { NewsPostEntity.fromModel(it) })
                }
            }
        }

        // 3. Observe Firebase RTDB settings -> sync to Room
        scope.launch(Dispatchers.IO) {
            firebaseManager.remoteSettings.collect { remoteSettings ->
                if (remoteSettings != null) {
                    newsDao.saveSettings(SiteSettingsEntity.fromModel(remoteSettings))
                }
            }
        }

        // 4. Observe Firebase RTDB banners -> sync to Room
        scope.launch(Dispatchers.IO) {
            firebaseManager.remoteBanners.collect { remoteBanners ->
                if (remoteBanners != null) {
                    newsDao.deleteAllBanners()
                    newsDao.insertBanners(remoteBanners.map { BannerEntity.fromModel(it) })
                }
            }
        }

        // 5. Observe Firebase RTDB gems -> sync to Room
        scope.launch(Dispatchers.IO) {
            firebaseManager.remoteGems.collect { remoteGems ->
                if (remoteGems != null) {
                    newsDao.deleteAllGems()
                    newsDao.insertGems(remoteGems.map { GemEntity.fromModel(it) })
                }
            }
        }

        // 6. Seed Firebase with defaults if empty
        firebaseManager.seedInitialDataIfEmpty(
            posts = NewsPost.DEFAULT_POSTS,
            defaultSettings = SiteSettings(),
            defaultBanners = BannerItem.DEFAULT_BANNERS,
            defaultGems = GemItem.DEFAULT_GEMS
        )
    }

    private suspend fun checkAndSeedLocalDatabase() {
        newsDao.saveSettings(SiteSettingsEntity.fromModel(SiteSettings()))
        newsDao.insertPosts(NewsPost.DEFAULT_POSTS.map { NewsPostEntity.fromModel(it) })
        newsDao.insertBanners(BannerItem.DEFAULT_BANNERS.map { BannerEntity.fromModel(it) })
        newsDao.insertGems(GemItem.DEFAULT_GEMS.map { GemEntity.fromModel(it) })
    }

    // Post operations
    suspend fun addPost(post: NewsPost, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.insertPost(NewsPostEntity.fromModel(post))
        firebaseManager.addOrUpdatePost(post, onComplete)
    }

    suspend fun deletePost(postId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.deletePost(postId)
        firebaseManager.deletePost(postId, onComplete)
    }

    suspend fun deleteAllPosts(onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.deleteAllPosts()
        firebaseManager.clearAllPosts(onComplete)
    }

    // Settings operations
    suspend fun updateSettings(settings: SiteSettings, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.saveSettings(SiteSettingsEntity.fromModel(settings))
        firebaseManager.updateSettings(settings, onComplete)
    }

    suspend fun setMaintenance(enabled: Boolean, onComplete: ((Boolean, String?) -> Unit)? = null) {
        val currentSettings = SiteSettingsEntity.fromModel(SiteSettings(maintenance = enabled))
        newsDao.saveSettings(currentSettings)
        firebaseManager.setMaintenance(enabled, onComplete)
    }

    // Banner operations
    suspend fun addOrUpdateBanner(banner: BannerItem, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.insertBanner(BannerEntity.fromModel(banner))
        firebaseManager.addOrUpdateBanner(banner, onComplete)
    }

    suspend fun deleteBanner(bannerId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.deleteBanner(bannerId)
        firebaseManager.deleteBanner(bannerId, onComplete)
    }

    // Gem operations
    suspend fun addOrUpdateGem(gem: GemItem, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.insertGem(GemEntity.fromModel(gem))
        firebaseManager.addOrUpdateGem(gem, onComplete)
    }

    suspend fun deleteGem(gemId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        newsDao.deleteGem(gemId)
        firebaseManager.deleteGem(gemId, onComplete)
    }

    fun reconnectFirebase(customUrl: String?) {
        firebaseManager.initializeFirebase(customUrl)
    }
}

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.data.model.SiteSettings

@Entity(tableName = "posts")
data class NewsPostEntity(
    @PrimaryKey val id: String,
    val cat: String,
    val title: String,
    val text: String,
    val image: String,
    val timestamp: Long
) {
    fun toModel(): NewsPost = NewsPost(
        id = id,
        cat = cat,
        title = title,
        text = text,
        image = image,
        timestamp = timestamp
    )

    companion object {
        fun fromModel(post: NewsPost): NewsPostEntity = NewsPostEntity(
            id = post.id,
            cat = post.cat,
            title = post.title,
            text = post.text,
            image = post.image,
            timestamp = post.timestamp
        )
    }
}

@Entity(tableName = "site_settings")
data class SiteSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val about: String,
    val maintenance: Boolean,
    val customRtdbUrl: String
) {
    fun toModel(): SiteSettings = SiteSettings(
        name = name,
        about = about,
        maintenance = maintenance,
        customRtdbUrl = customRtdbUrl
    )

    companion object {
        fun fromModel(settings: SiteSettings): SiteSettingsEntity = SiteSettingsEntity(
            id = 1,
            name = settings.name,
            about = settings.about,
            maintenance = settings.maintenance,
            customRtdbUrl = settings.customRtdbUrl
        )
    }
}

@Entity(tableName = "banners")
data class BannerEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String,
    val image: String,
    val order: Int,
    val linkUrl: String,
    val timestamp: Long
) {
    fun toModel(): BannerItem = BannerItem(
        id = id,
        title = title,
        subtitle = subtitle,
        image = image,
        order = order,
        linkUrl = linkUrl,
        timestamp = timestamp
    )

    companion object {
        fun fromModel(banner: BannerItem): BannerEntity = BannerEntity(
            id = banner.id,
            title = banner.title,
            subtitle = banner.subtitle,
            image = banner.image,
            order = banner.order,
            linkUrl = banner.linkUrl,
            timestamp = banner.timestamp
        )
    }
}

@Entity(tableName = "gems")
data class GemEntity(
    @PrimaryKey val id: String,
    val name: String,
    val price: String,
    val image: String,
    val buttonLabel: String,
    val buttonLink: String,
    val order: Int,
    val timestamp: Long
) {
    fun toModel(): GemItem = GemItem(
        id = id,
        name = name,
        price = price,
        image = image,
        buttonLabel = buttonLabel,
        buttonLink = buttonLink,
        order = order,
        timestamp = timestamp
    )

    companion object {
        fun fromModel(gem: GemItem): GemEntity = GemEntity(
            id = gem.id,
            name = gem.name,
            price = gem.price,
            image = gem.image,
            buttonLabel = gem.buttonLabel,
            buttonLink = gem.buttonLink,
            order = gem.order,
            timestamp = gem.timestamp
        )
    }
}

package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FreeFireColorScheme = darkColorScheme(
    primary = FFAccent,
    onPrimary = Color.White,
    primaryContainer = FFAccent2,
    onPrimaryContainer = Color.White,
    secondary = FFAccentGold,
    onSecondary = Color.Black,
    secondaryContainer = FFPanel2,
    onSecondaryContainer = FFText,
    tertiary = FFOk,
    onTertiary = Color.White,
    background = FFBg,
    onBackground = FFText,
    surface = FFPanel,
    onSurface = FFText,
    surfaceVariant = FFPanel2,
    onSurfaceVariant = FFMuted,
    outline = FFLine,
    error = FFDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Free Fire News Center is a sleek gaming dark interface
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FreeFireColorScheme,
        typography = Typography,
        content = content
    )
}

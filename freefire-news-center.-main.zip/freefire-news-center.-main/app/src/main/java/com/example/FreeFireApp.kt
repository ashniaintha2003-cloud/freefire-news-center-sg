package com.example

import android.app.Application
import com.example.data.repository.NewsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class FreeFireApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    lateinit var repository: NewsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = NewsRepository(this, applicationScope)
    }
}

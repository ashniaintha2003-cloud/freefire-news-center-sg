package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.FreeFireApp
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.data.model.SiteSettings
import com.example.data.repository.NewsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NewsUiState(
    val posts: List<NewsPost> = emptyList(),
    val filteredPosts: List<NewsPost> = emptyList(),
    val banners: List<BannerItem> = emptyList(),
    val gems: List<GemItem> = emptyList(),
    val selectedCategory: String = "all",
    val searchQuery: String = "",
    val siteSettings: SiteSettings = SiteSettings(),
    val isFirebaseConnected: Boolean = false,
    val selectedArticle: NewsPost? = null,
    val isAdminLoggedIn: Boolean = false,
    val showLoginDialog: Boolean = false,
    val showAdminPanel: Boolean = false,
    val loginError: String? = null,
    val adminActionMessage: String? = null
)

class NewsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NewsRepository = (application as FreeFireApp).repository

    private val _selectedCategory = MutableStateFlow("all")
    private val _searchQuery = MutableStateFlow("")
    private val _selectedArticle = MutableStateFlow<NewsPost?>(null)
    private val _isAdminLoggedIn = MutableStateFlow(false)
    private val _showLoginDialog = MutableStateFlow(false)
    private val _showAdminPanel = MutableStateFlow(false)
    private val _loginError = MutableStateFlow<String?>(null)
    private val _adminActionMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<NewsUiState> = combine(
        repository.postsFlow,
        repository.settingsFlow,
        repository.bannersFlow,
        repository.gemsFlow,
        repository.isFirebaseConnected,
        _selectedCategory,
        _searchQuery,
        _selectedArticle,
        _isAdminLoggedIn,
        _showLoginDialog,
        _showAdminPanel,
        _loginError,
        _adminActionMessage
    ) { args: Array<Any?> ->
        @Suppress("UNCHECKED_CAST")
        val posts = args[0] as List<NewsPost>
        val settings = args[1] as SiteSettings
        @Suppress("UNCHECKED_CAST")
        val banners = args[2] as List<BannerItem>
        @Suppress("UNCHECKED_CAST")
        val gems = args[3] as List<GemItem>
        val isConnected = args[4] as Boolean
        val cat = args[5] as String
        val query = args[6] as String
        val article = args[7] as NewsPost?
        val isAdmin = args[8] as Boolean
        val showLogin = args[9] as Boolean
        val showAdmin = args[10] as Boolean
        val loginErr = args[11] as String?
        val actionMsg = args[12] as String?

        val trimmedQuery = query.trim().lowercase()
        val filtered = posts.filter { post ->
            val matchesCategory = cat == "all" || post.cat.equals(cat, ignoreCase = true)
            val matchesQuery = trimmedQuery.isEmpty() ||
                    post.title.lowercase().contains(trimmedQuery) ||
                    post.text.lowercase().contains(trimmedQuery)
            matchesCategory && matchesQuery
        }

        NewsUiState(
            posts = posts,
            filteredPosts = filtered,
            banners = banners,
            gems = gems,
            selectedCategory = cat,
            searchQuery = query,
            siteSettings = settings,
            isFirebaseConnected = isConnected,
            selectedArticle = article,
            isAdminLoggedIn = isAdmin,
            showLoginDialog = showLogin,
            showAdminPanel = showAdmin,
            loginError = loginErr,
            adminActionMessage = actionMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = NewsUiState()
    )

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openArticle(post: NewsPost) {
        _selectedArticle.value = post
    }

    fun closeArticle() {
        _selectedArticle.value = null
    }

    fun openLoginDialog() {
        _loginError.value = null
        _showLoginDialog.value = true
    }

    fun closeLoginDialog() {
        _showLoginDialog.value = false
        _loginError.value = null
    }

    fun login(username: String, pass: String): Boolean {
        return if (username.trim() == "ASHNI" && pass == "ASHNI2027") {
            _isAdminLoggedIn.value = true
            _showLoginDialog.value = false
            _showAdminPanel.value = true
            _loginError.value = null
            true
        } else {
            _loginError.value = "Incorrect username or password."
            false
        }
    }

    fun logout() {
        _isAdminLoggedIn.value = false
        _showAdminPanel.value = false
        _loginError.value = null
    }

    fun openAdminPanel() {
        if (_isAdminLoggedIn.value) {
            _showAdminPanel.value = true
        } else {
            openLoginDialog()
        }
    }

    fun closeAdminPanel() {
        _showAdminPanel.value = false
    }

    fun saveSettings(name: String, about: String) {
        viewModelScope.launch {
            val current = uiState.value.siteSettings
            val updated = current.copy(
                name = name.trim().ifEmpty { "FREE FIRE NEWS CENTER" },
                about = about.trim()
            )
            repository.updateSettings(updated) { success, _ ->
                _adminActionMessage.value = if (success) "Settings saved in real time to Firebase!" else "Saved locally"
            }
        }
    }

    fun toggleMaintenance() {
        viewModelScope.launch {
            val current = uiState.value.siteSettings.maintenance
            val updated = !current
            repository.setMaintenance(updated) { success, _ ->
                _adminActionMessage.value = if (updated) "Maintenance mode is now ON" else "Maintenance mode turned OFF"
            }
        }
    }

    fun addPost(title: String, cat: String, text: String, imageBase64: String) {
        viewModelScope.launch {
            val newPost = NewsPost(
                id = System.currentTimeMillis().toString(),
                cat = cat.lowercase().trim(),
                title = title.trim(),
                text = text.trim(),
                image = imageBase64.trim(),
                timestamp = System.currentTimeMillis()
            )
            repository.addPost(newPost) { success, _ ->
                _adminActionMessage.value = if (success) "Post published in real time!" else "Post saved locally"
            }
        }
    }

    fun deletePost(id: String) {
        viewModelScope.launch {
            repository.deletePost(id) { success, _ ->
                _adminActionMessage.value = if (success) "Post deleted from Firebase" else "Post removed"
            }
        }
    }

    fun clearAllPosts() {
        viewModelScope.launch {
            repository.deleteAllPosts { success, _ ->
                _adminActionMessage.value = if (success) "All posts deleted from Firebase" else "Posts cleared"
            }
        }
    }

    // Banner management
    fun saveBanner(
        id: String?,
        title: String,
        subtitle: String,
        imageBase64: String,
        order: Int,
        linkUrl: String
    ) {
        viewModelScope.launch {
            val bannerId = id?.ifBlank { null } ?: ("banner-" + System.currentTimeMillis())
            val existing = uiState.value.banners.firstOrNull { it.id == bannerId }
            val banner = BannerItem(
                id = bannerId,
                title = title.trim(),
                subtitle = subtitle.trim(),
                image = imageBase64.ifBlank { existing?.image ?: "" },
                order = order,
                linkUrl = linkUrl.trim(),
                timestamp = existing?.timestamp ?: System.currentTimeMillis()
            )
            repository.addOrUpdateBanner(banner) { success, _ ->
                _adminActionMessage.value = if (success) "Banner saved in real time to Firebase!" else "Banner saved locally"
            }
        }
    }

    fun deleteBanner(id: String) {
        viewModelScope.launch {
            repository.deleteBanner(id) { success, _ ->
                _adminActionMessage.value = if (success) "Banner deleted from Firebase" else "Banner removed"
            }
        }
    }

    fun moveBannerOrder(banner: BannerItem, delta: Int) {
        viewModelScope.launch {
            val currentList = uiState.value.banners.toMutableList()
            val index = currentList.indexOfFirst { it.id == banner.id }
            val targetIndex = index + delta
            if (index != -1 && targetIndex in currentList.indices) {
                val targetBanner = currentList[targetIndex]
                val updatedThis = banner.copy(order = targetBanner.order)
                val updatedTarget = targetBanner.copy(order = banner.order)
                repository.addOrUpdateBanner(updatedThis)
                repository.addOrUpdateBanner(updatedTarget) { success, _ ->
                    _adminActionMessage.value = if (success) "Banner order updated in real time!" else "Order updated"
                }
            }
        }
    }

    // Gem management
    fun saveGem(
        id: String?,
        name: String,
        price: String,
        imageBase64: String,
        buttonLabel: String,
        buttonLink: String,
        order: Int
    ) {
        viewModelScope.launch {
            val gemId = id?.ifBlank { null } ?: ("gem-" + System.currentTimeMillis())
            val existing = uiState.value.gems.firstOrNull { it.id == gemId }
            val gem = GemItem(
                id = gemId,
                name = name.trim(),
                price = price.trim(),
                image = imageBase64.ifBlank { existing?.image ?: "" },
                buttonLabel = buttonLabel.trim().ifEmpty { "Top Up" },
                buttonLink = buttonLink.trim(),
                order = order,
                timestamp = existing?.timestamp ?: System.currentTimeMillis()
            )
            repository.addOrUpdateGem(gem) { success, _ ->
                _adminActionMessage.value = if (success) "Gem card saved in real time to Firebase!" else "Gem card saved locally"
            }
        }
    }

    fun deleteGem(id: String) {
        viewModelScope.launch {
            repository.deleteGem(id) { success, _ ->
                _adminActionMessage.value = if (success) "Gem card deleted from Firebase" else "Gem card removed"
            }
        }
    }

    fun moveGemOrder(gem: GemItem, delta: Int) {
        viewModelScope.launch {
            val currentList = uiState.value.gems.toMutableList()
            val index = currentList.indexOfFirst { it.id == gem.id }
            val targetIndex = index + delta
            if (index != -1 && targetIndex in currentList.indices) {
                val targetGem = currentList[targetIndex]
                val updatedThis = gem.copy(order = targetGem.order)
                val updatedTarget = targetGem.copy(order = gem.order)
                repository.addOrUpdateGem(updatedThis)
                repository.addOrUpdateGem(updatedTarget) { success, _ ->
                    _adminActionMessage.value = if (success) "Gem order updated in real time!" else "Order updated"
                }
            }
        }
    }

    fun clearAdminActionMessage() {
        _adminActionMessage.value = null
    }

    fun updateCustomRtdbUrl(url: String) {
        viewModelScope.launch {
            val current = uiState.value.siteSettings
            val updated = current.copy(customRtdbUrl = url.trim())
            repository.updateSettings(updated)
            repository.reconnectFirebase(url.trim())
            _adminActionMessage.value = "Reconnecting to: $url"
        }
    }
}

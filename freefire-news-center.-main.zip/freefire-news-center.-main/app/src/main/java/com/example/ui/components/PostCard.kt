package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.NewsPost
import com.example.ui.theme.FFAccent
import com.example.ui.theme.FFAccent2
import com.example.ui.theme.FFLine
import com.example.ui.theme.FFMuted
import com.example.ui.theme.FFPanelCard
import com.example.ui.theme.FFPanel2
import com.example.ui.theme.FFPurpleTagBg
import com.example.ui.theme.FFPurpleTagText
import com.example.ui.theme.FFText

@Composable
fun PostCard(
    post: NewsPost,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(width = 1.dp, color = FFLine, shape = RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("post_card_${post.id}"),
        colors = CardDefaults.cardColors(
            containerColor = FFPanelCard
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Thumbnail container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF202533),
                                Color(0xFF11131A)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (post.image.isNotBlank()) {
                    AsyncImage(
                        model = post.image,
                        contentDescription = post.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.matchParentSize()
                    )
                } else {
                    // Stylized Cyber Gaming Thumbnail for Free Fire
                    PostThumbnailGraphic(post.cat)
                }

                // Category Tag Overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xE607080C))
                        .border(1.dp, FFAccent.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = post.cat.uppercase(),
                        color = FFPurpleTagText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Card Body
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = post.title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = FFText,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = post.text,
                    fontSize = 13.sp,
                    color = FFMuted,
                    lineHeight = 18.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FFPanel2,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("read_article_${post.id}")
                ) {
                    Text(
                        text = "Read Article",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun PostThumbnailGraphic(category: String) {
    val (icon, label) = when (category.lowercase()) {
        "news" -> Icons.Default.Campaign to "FREE FIRE NEWS"
        "update" -> Icons.Default.Upgrade to "OB48 UPDATE"
        "events" -> Icons.Default.Event to "SPECIAL EVENT"
        "craftland" -> Icons.Default.Construction to "CRAFTLAND MAP"
        else -> Icons.Default.SportsEsports to "FREE FIRE"
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(FFAccent.copy(alpha = 0.15f))
                .border(1.dp, FFAccent.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = FFAccent,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            color = FFMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
    }
}

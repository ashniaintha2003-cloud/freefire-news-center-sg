package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.InputStream

object ImageUtils {
    private const val TAG = "ImageUtils"

    /**
     * Reads an image Uri from device storage/gallery, resizes it so max dimension is 800px,
     * compresses to JPEG with 80% quality, and returns a Base64 data URL string.
     */
    fun uriToBase64(context: Context, uri: Uri, maxDimension: Int = 800, quality: Int = 80): String? {
        var inputStream: InputStream? = null
        return try {
            inputStream = context.contentResolver.openInputStream(uri) ?: return null

            // First decode with inJustDecodeBounds to get dimensions
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()

            // Calculate sample size
            var sampleSize = 1
            val maxOriginal = maxOf(options.outWidth, options.outHeight)
            if (maxOriginal > maxDimension) {
                sampleSize = Math.round(maxOriginal.toFloat() / maxDimension.toFloat())
            }

            // Decode scaled bitmap
            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            inputStream = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions) ?: return null

            // Further scale if needed
            val scaledBitmap = if (bitmap.width > maxDimension || bitmap.height > maxDimension) {
                val ratio = minOf(
                    maxDimension.toFloat() / bitmap.width,
                    maxDimension.toFloat() / bitmap.height
                )
                val width = (bitmap.width * ratio).toInt()
                val height = (bitmap.height * ratio).toInt()
                Bitmap.createScaledBitmap(bitmap, maxOf(1, width), maxOf(1, height), true)
            } else {
                bitmap
            }

            // Compress to JPEG byte array
            val outputStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
            val byteArray = outputStream.toByteArray()

            // Base64 encode
            val base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP)
            "data:image/jpeg;base64,$base64"
        } catch (e: Exception) {
            Log.e(TAG, "Failed to convert Uri to Base64: ${e.message}", e)
            null
        } finally {
            try {
                inputStream?.close()
            } catch (ignored: Exception) {}
        }
    }
}

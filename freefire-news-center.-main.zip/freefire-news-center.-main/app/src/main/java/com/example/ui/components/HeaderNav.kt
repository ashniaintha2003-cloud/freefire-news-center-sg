package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FFAccent
import com.example.ui.theme.FFBg
import com.example.ui.theme.FFLine
import com.example.ui.theme.FFMuted
import com.example.ui.theme.FFOk
import com.example.ui.theme.FFPanel
import com.example.ui.theme.FFPanel2
import com.example.ui.theme.FFText

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HeaderNav(
    siteName: String,
    selectedCategory: String,
    isFirebaseConnected: Boolean,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isMenuOpen by remember { mutableStateOf(false) }

    val categories = listOf(
        "all" to "HOME",
        "news" to "NEWS",
        "update" to "UPDATES",
        "events" to "EVENTS",
        "craftland" to "CRAFTLAND"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(FFBg.copy(alpha = 0.95f))
            .border(width = 1.dp, color = FFLine)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Name & Icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { onCategorySelected("all") }
                    .testTag("brand_logo")
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(FFAccent.copy(alpha = 0.2f))
                        .border(1.dp, FFAccent.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Whatshot,
                        contentDescription = "Flame Logo",
                        tint = FFAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (siteName.contains("FREE FIRE", ignoreCase = true)) "FREE FIRE " else siteName,
                            fontWeight = FontWeight.Black,
                            fontSize = 17.sp,
                            color = FFText,
                            letterSpacing = 0.5.sp
                        )
                        if (siteName.contains("FREE FIRE", ignoreCase = true)) {
                            Text(
                                text = "NEWS",
                                fontWeight = FontWeight.Black,
                                fontSize = 17.sp,
                                color = FFAccent,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Real-Time Firebase sync pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isFirebaseConnected) FFOk else FFMuted)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isFirebaseConnected) "Firebase Live Sync" else "Firebase Realtime DB",
                            fontSize = 10.sp,
                            color = if (isFirebaseConnected) FFOk else FFMuted,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Menu Toggle Button
            IconButton(
                onClick = { isMenuOpen = !isMenuOpen },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(FFPanel2)
                    .size(38.dp)
                    .testTag("nav_menu_button")
            ) {
                Icon(
                    imageVector = if (isMenuOpen) Icons.Default.Close else Icons.Default.Menu,
                    contentDescription = "Navigation Menu",
                    tint = FFText
                )
            }
        }

        // Expandable Categories Navigation
        AnimatedVisibility(visible = isMenuOpen) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(FFPanel)
                    .border(width = 1.dp, color = FFLine)
                    .padding(12.dp)
            ) {
                Text(
                    text = "CATEGORIES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = FFMuted,
                    modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
                )

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { (key, label) ->
                        val isSelected = selectedCategory.equals(key, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) FFAccent else FFPanel2)
                                .border(
                                    1.dp,
                                    if (isSelected) FFAccent else FFLine,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    onCategorySelected(key)
                                    isMenuOpen = false
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("nav_item_$key"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isSelected) Color.White else FFMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

package com.example.data.model

data class NewsPost(
    val id: String = "",
    val cat: String = "news",
    val title: String = "",
    val text: String = "",
    val image: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "cat" to cat,
        "title" to title,
        "text" to text,
        "image" to image,
        "timestamp" to timestamp
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): NewsPost {
            return NewsPost(
                id = map["id"]?.toString() ?: "",
                cat = map["cat"]?.toString() ?: "news",
                title = map["title"]?.toString() ?: "",
                text = map["text"]?.toString() ?: "",
                image = map["image"]?.toString() ?: "",
                timestamp = (map["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }

        val DEFAULT_POSTS = listOf(
            NewsPost(
                id = "1",
                cat = "news",
                title = "Free Fire Latest News",
                text = "Read the latest Free Fire news and announcements. Patch OB48 introduces revamped ranked modes, weapon balance adjustments, and exclusive anniversary rewards for all survivors.",
                image = ""
            ),
            NewsPost(
                id = "2",
                cat = "update",
                title = "New Free Fire Update",
                text = "Discover new features and game changes. The newest update brings optimized Battle Royale gameplay, tactical air drops, new cyber character abilities, and smoother frame rates.",
                image = ""
            ),
            NewsPost(
                id = "3",
                cat = "events",
                title = "Upcoming Events",
                text = "Check upcoming Free Fire events and activities. Compete in the Rampage Festival, join weekly squad tournaments, and unlock legendary weapon skins during the limited-time festival!",
                image = ""
            ),
            NewsPost(
                id = "4",
                cat = "craftland",
                title = "New Craftland Maps",
                text = "Explore interesting Craftland maps and creator content. Try intense 1v1 sniper arenas, parkour challenge runs, and zombie survival modes designed by top community architects.",
                image = ""
            ),
            NewsPost(
                id = "5",
                cat = "news",
                title = "Community News",
                text = "Important community news and announcements. Global championship qualifiers are starting this weekend. Watch the official live streams for free diamond drops and custom room cards.",
                image = ""
            ),
            NewsPost(
                id = "6",
                cat = "update",
                title = "Game Changes & Features",
                text = "See new features and improvements. Enhanced anti-cheat detection, improved quick-switch controls, refined vehicle handling, and balanced Clash Squad weapon economies.",
                image = ""
            )
        )
    }
}

data class SiteSettings(
    val name: String = "FREE FIRE NEWS CENTER",
    val about: String = "A smooth Free Fire news website template.",
    val maintenance: Boolean = false,
    val customRtdbUrl: String = ""
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "name" to name,
        "about" to about,
        "maintenance" to maintenance,
        "customRtdbUrl" to customRtdbUrl
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): SiteSettings {
            return SiteSettings(
                name = map["name"]?.toString() ?: "FREE FIRE NEWS CENTER",
                about = map["about"]?.toString() ?: "A smooth Free Fire news website template.",
                maintenance = (map["maintenance"] as? Boolean) ?: false,
                customRtdbUrl = map["customRtdbUrl"]?.toString() ?: ""
            )
        }
    }
}

data class BannerItem(
    val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val image: String = "",
    val order: Int = 0,
    val linkUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "title" to title,
        "subtitle" to subtitle,
        "image" to image,
        "order" to order,
        "linkUrl" to linkUrl,
        "timestamp" to timestamp
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): BannerItem {
            return BannerItem(
                id = map["id"]?.toString() ?: "",
                title = map["title"]?.toString() ?: "",
                subtitle = map["subtitle"]?.toString() ?: "",
                image = map["image"]?.toString() ?: "",
                order = (map["order"] as? Number)?.toInt() ?: 0,
                linkUrl = map["linkUrl"]?.toString() ?: "",
                timestamp = (map["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }

        val DEFAULT_BANNERS = listOf(
            BannerItem(
                id = "banner-1",
                title = "FREE FIRE OB48 UPDATE",
                subtitle = "New ranked season, reworked weapon balances, and cyber abilities",
                image = "",
                order = 1
            ),
            BannerItem(
                id = "banner-2",
                title = "RAMPAGE FESTIVAL 2026",
                subtitle = "Limited-time royale challenges and exclusive legendary bundles",
                image = "",
                order = 2
            ),
            BannerItem(
                id = "banner-3",
                title = "CRAFTLAND CREATOR ARENA",
                subtitle = "Top community 1v1 arenas, parkour escapes, and custom maps",
                image = "",
                order = 3
            )
        )
    }
}

data class GemItem(
    val id: String = "",
    val name: String = "",
    val price: String = "",
    val image: String = "",
    val buttonLabel: String = "Top Up",
    val buttonLink: String = "",
    val order: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "name" to name,
        "price" to price,
        "image" to image,
        "buttonLabel" to buttonLabel,
        "buttonLink" to buttonLink,
        "order" to order,
        "timestamp" to timestamp
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): GemItem {
            return GemItem(
                id = map["id"]?.toString() ?: "",
                name = map["name"]?.toString() ?: "",
                price = map["price"]?.toString() ?: "",
                image = map["image"]?.toString() ?: "",
                buttonLabel = map["buttonLabel"]?.toString() ?: "Top Up",
                buttonLink = map["buttonLink"]?.toString() ?: "",
                order = (map["order"] as? Number)?.toInt() ?: 0,
                timestamp = (map["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }

        val DEFAULT_GEMS = listOf(
            GemItem(
                id = "gem-1",
                name = "100 + 10 Bonus Diamonds",
                price = "$0.99",
                image = "",
                buttonLabel = "Top Up",
                buttonLink = "https://reward.ff.garena.com",
                order = 1
            ),
            GemItem(
                id = "gem-2",
                name = "310 + 31 Bonus Diamonds",
                price = "$2.99",
                image = "",
                buttonLabel = "Top Up",
                buttonLink = "https://reward.ff.garena.com",
                order = 2
            ),
            GemItem(
                id = "gem-3",
                name = "520 + 52 Bonus Diamonds",
                price = "$4.99",
                image = "",
                buttonLabel = "Top Up",
                buttonLink = "https://reward.ff.garena.com",
                order = 3
            ),
            GemItem(
                id = "gem-4",
                name = "1060 + 106 Bonus Diamonds",
                price = "$9.99",
                image = "",
                buttonLabel = "Top Up",
                buttonLink = "https://reward.ff.garena.com",
                order = 4
            ),
            GemItem(
                id = "gem-5",
                name = "Weekly Diamond Pass",
                price = "$1.99",
                image = "",
                buttonLabel = "Claim Pass",
                buttonLink = "https://reward.ff.garena.com",
                order = 5
            ),
            GemItem(
                id = "gem-6",
                name = "Monthly VIP Membership",
                price = "$7.99",
                image = "",
                buttonLabel = "Subscribe",
                buttonLink = "https://reward.ff.garena.com",
                order = 6
            )
        )
    }
}

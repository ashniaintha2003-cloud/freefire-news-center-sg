package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NewsDao {
    // Posts
    @Query("SELECT * FROM posts ORDER BY timestamp DESC")
    fun getAllPosts(): Flow<List<NewsPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<NewsPostEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: NewsPostEntity)

    @Query("DELETE FROM posts WHERE id = :id")
    suspend fun deletePost(id: String)

    @Query("DELETE FROM posts")
    suspend fun deleteAllPosts()

    // Site Settings
    @Query("SELECT * FROM site_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<SiteSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: SiteSettingsEntity)

    // Banners
    @Query("SELECT * FROM banners ORDER BY `order` ASC, timestamp DESC")
    fun getAllBanners(): Flow<List<BannerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanners(banners: List<BannerEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanner(banner: BannerEntity)

    @Query("DELETE FROM banners WHERE id = :id")
    suspend fun deleteBanner(id: String)

    @Query("DELETE FROM banners")
    suspend fun deleteAllBanners()

    // Gems
    @Query("SELECT * FROM gems ORDER BY `order` ASC, timestamp DESC")
    fun getAllGems(): Flow<List<GemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGems(gems: List<GemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGem(gem: GemEntity)

    @Query("DELETE FROM gems WHERE id = :id")
    suspend fun deleteGem(id: String)

    @Query("DELETE FROM gems")
    suspend fun deleteAllGems()
}

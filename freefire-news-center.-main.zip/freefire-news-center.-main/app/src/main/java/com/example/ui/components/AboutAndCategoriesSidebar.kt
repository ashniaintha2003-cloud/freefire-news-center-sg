package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FFAccent
import com.example.ui.theme.FFLine
import com.example.ui.theme.FFMuted
import com.example.ui.theme.FFPanel
import com.example.ui.theme.FFPanel2
import com.example.ui.theme.FFText

@Composable
fun AboutAndCategoriesSidebar(
    aboutText: String,
    onCategorySelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf(
        "news" to "Free Fire News",
        "update" to "Game Updates",
        "events" to "Upcoming Events",
        "craftland" to "Craftland Maps"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Popular Categories Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, FFLine, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = FFPanel)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(FFAccent.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = null,
                            tint = FFAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = " Popular Categories",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = FFText
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                categories.forEach { (catId, catLabel) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onCategorySelected(catId) }
                            .padding(vertical = 10.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = catLabel,
                            fontSize = 13.sp,
                            color = FFMuted,
                            fontWeight = FontWeight.Medium
                        )
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = FFAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // About Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, FFLine, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = FFPanel)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(FFAccent.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = FFAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = " About",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = FFText
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = aboutText.ifBlank { "A smooth Free Fire news website template." },
                    fontSize = 13.sp,
                    color = FFMuted,
                    lineHeight = 20.sp,
                    modifier = Modifier.testTag("about_text_view")
                )
            }
        }

        // Footer
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "© 2026 Free Fire News • All Rights Reserved",
                fontSize = 12.sp,
                color = FFMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}

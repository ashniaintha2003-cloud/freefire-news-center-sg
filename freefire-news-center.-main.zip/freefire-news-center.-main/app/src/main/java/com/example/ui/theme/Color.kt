package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FFBg = Color(0xFF07080C)
val FFPanel = Color(0xFF10121A)
val FFPanel2 = Color(0xFF171A24)
val FFPanelCard = Color(0xFF121520)
val FFText = Color(0xFFF7F7FB)
val FFMuted = Color(0xFF9AA3B5)
val FFAccent = Color(0xFFA855F7)
val FFAccent2 = Color(0xFF7C3AED)
val FFAccentGold = Color(0xFFFFB800)
val FFLine = Color(0xFF282D39)
val FFDanger = Color(0xFFEF4444)
val FFOk = Color(0xFF22C55E)
val FFPurpleTagBg = Color(0x28A855F7)
val FFPurpleTagText = Color(0xFFD8B4FE)
val FFMaintenanceBg = Color(0x28EF4444)
val FFMaintenanceBorder = Color(0x66EF4444)

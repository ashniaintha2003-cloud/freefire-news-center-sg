package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.ui.NewsUiState
import com.example.ui.NewsViewModel
import com.example.ui.components.AboutAndCategoriesSidebar
import com.example.ui.components.AdminLoginDialog
import com.example.ui.components.AdminPanelDialog
import com.example.ui.components.ArticleModal
import com.example.ui.components.BannerSlideshow
import com.example.ui.components.CategoryChipsAndSearch
import com.example.ui.components.GemsSection
import com.example.ui.components.HeaderNav
import com.example.ui.components.MaintenanceScreen
import com.example.ui.components.PostCard
import com.example.ui.theme.FFAccent
import com.example.ui.theme.FFBg
import com.example.ui.theme.FFLine
import com.example.ui.theme.FFMuted
import com.example.ui.theme.FFPanel
import com.example.ui.theme.FFPanel2
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: NewsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                FreeFireNewsApp(
                    uiState = uiState,
                    onCategorySelected = viewModel::selectCategory,
                    onSearchQueryChanged = viewModel::updateSearchQuery,
                    onOpenArticle = viewModel::openArticle,
                    onCloseArticle = viewModel::closeArticle,
                    onOpenLogin = viewModel::openLoginDialog,
                    onCloseLogin = viewModel::closeLoginDialog,
                    onLogin = viewModel::login,
                    onLogout = viewModel::logout,
                    onOpenAdmin = viewModel::openAdminPanel,
                    onCloseAdmin = viewModel::closeAdminPanel,
                    onSaveSettings = viewModel::saveSettings,
                    onToggleMaintenance = viewModel::toggleMaintenance,
                    onAddPost = viewModel::addPost,
                    onDeletePost = viewModel::deletePost,
                    onClearAllPosts = viewModel::clearAllPosts,
                    onSaveBanner = viewModel::saveBanner,
                    onDeleteBanner = viewModel::deleteBanner,
                    onMoveBannerOrder = viewModel::moveBannerOrder,
                    onSaveGem = viewModel::saveGem,
                    onDeleteGem = viewModel::deleteGem,
                    onMoveGemOrder = viewModel::moveGemOrder,
                    onUpdateCustomRtdbUrl = viewModel::updateCustomRtdbUrl
                )
            }
        }
    }
}

@Composable
fun FreeFireNewsApp(
    uiState: NewsUiState,
    onCategorySelected: (String) -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onOpenArticle: (NewsPost) -> Unit,
    onCloseArticle: () -> Unit,
    onOpenLogin: () -> Unit,
    onCloseLogin: () -> Unit,
    onLogin: (String, String) -> Boolean,
    onLogout: () -> Unit,
    onOpenAdmin: () -> Unit,
    onCloseAdmin: () -> Unit,
    onSaveSettings: (String, String) -> Unit,
    onToggleMaintenance: () -> Unit,
    onAddPost: (String, String, String, String) -> Unit,
    onDeletePost: (String) -> Unit,
    onClearAllPosts: () -> Unit,
    onSaveBanner: (String?, String, String, String, Int, String) -> Unit,
    onDeleteBanner: (String) -> Unit,
    onMoveBannerOrder: (BannerItem, Int) -> Unit,
    onSaveGem: (String?, String, String, String, String, String, Int) -> Unit,
    onDeleteGem: (String) -> Unit,
    onMoveGemOrder: (GemItem, Int) -> Unit,
    onUpdateCustomRtdbUrl: (String) -> Unit
) {
    // Back navigation handling
    BackHandler(
        enabled = uiState.selectedArticle != null || uiState.showAdminPanel || uiState.showLoginDialog
    ) {
        when {
            uiState.selectedArticle != null -> onCloseArticle()
            uiState.showAdminPanel -> onCloseAdmin()
            uiState.showLoginDialog -> onCloseLogin()
        }
    }

    // Maintenance Mode Screen
    if (uiState.siteSettings.maintenance && !uiState.isAdminLoggedIn) {
        MaintenanceScreen(
            onAdminLoginClick = onOpenLogin,
            modifier = Modifier.fillMaxSize()
        )
    } else {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(FFBg),
            containerColor = FFBg,
            topBar = {
                HeaderNav(
                    siteName = uiState.siteSettings.name,
                    selectedCategory = uiState.selectedCategory,
                    isFirebaseConnected = uiState.isFirebaseConnected,
                    onCategorySelected = onCategorySelected,
                    modifier = Modifier.statusBarsPadding()
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = onOpenAdmin,
                    containerColor = FFPanel2,
                    contentColor = Color.White,
                    shape = CircleShape,
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
                    modifier = Modifier
                        .border(1.dp, FFLine, CircleShape)
                        .size(54.dp)
                        .navigationBarsPadding()
                        .testTag("admin_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Admin Login / Panel",
                        tint = FFAccent,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        ) { innerPadding ->
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                val isWideScreen = maxWidth >= 600.dp

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 5-Second Auto-scrolling Banner Slideshow (or Fallback Hero)
                    item {
                        BannerSlideshow(
                            banners = uiState.banners,
                            onNavigateNews = { onCategorySelected("news") },
                            onNavigateEvents = { onCategorySelected("events") }
                        )
                    }

                    // Diamond Store & Gems Section
                    item {
                        GemsSection(gems = uiState.gems)
                    }

                    // Category Chips and Search Bar
                    item {
                        CategoryChipsAndSearch(
                            selectedCategory = uiState.selectedCategory,
                            onCategorySelected = onCategorySelected,
                            searchQuery = uiState.searchQuery,
                            onSearchQueryChanged = onSearchQueryChanged,
                            postCount = uiState.filteredPosts.size
                        )
                    }

                    // Empty state when search or filter returns no posts
                    if (uiState.filteredPosts.isEmpty()) {
                        item {
                            EmptyPostsState(modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    } else {
                        // Posts Layout (2 columns if tablet/wide, 1 column if compact)
                        if (isWideScreen) {
                            val chunkedPosts = uiState.filteredPosts.chunked(2)
                            items(chunkedPosts) { pair ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Box(modifier = Modifier.weight(1f)) {
                                        PostCard(
                                            post = pair[0],
                                            onClick = { onOpenArticle(pair[0]) }
                                        )
                                    }
                                    if (pair.size > 1) {
                                        Box(modifier = Modifier.weight(1f)) {
                                            PostCard(
                                                post = pair[1],
                                                onClick = { onOpenArticle(pair[1]) }
                                            )
                                        }
                                    } else {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        } else {
                            items(uiState.filteredPosts, key = { it.id }) { post ->
                                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                                    PostCard(
                                        post = post,
                                        onClick = { onOpenArticle(post) }
                                    )
                                }
                            }
                        }
                    }

                    // Sidebar / Footer (Popular Categories & About Text)
                    item {
                        AboutAndCategoriesSidebar(
                            aboutText = uiState.siteSettings.about,
                            onCategorySelected = onCategorySelected
                        )
                    }

                    // Bottom spacing for FAB
                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    // Article Reader Modal
    uiState.selectedArticle?.let { article ->
        ArticleModal(
            post = article,
            onDismiss = onCloseArticle
        )
    }

    // Admin Login Modal
    if (uiState.showLoginDialog) {
        AdminLoginDialog(
            errorMsg = uiState.loginError,
            onLogin = { username, pass ->
                onLogin(username, pass)
            },
            onDismiss = onCloseLogin
        )
    }

    // Admin Panel Modal
    if (uiState.showAdminPanel) {
        AdminPanelDialog(
            settings = uiState.siteSettings,
            posts = uiState.posts,
            banners = uiState.banners,
            gems = uiState.gems,
            isFirebaseConnected = uiState.isFirebaseConnected,
            actionMessage = uiState.adminActionMessage,
            onSaveSettings = onSaveSettings,
            onToggleMaintenance = onToggleMaintenance,
            onAddPost = onAddPost,
            onDeletePost = onDeletePost,
            onClearAllPosts = onClearAllPosts,
            onSaveBanner = onSaveBanner,
            onDeleteBanner = onDeleteBanner,
            onMoveBannerOrder = onMoveBannerOrder,
            onSaveGem = onSaveGem,
            onDeleteGem = onDeleteGem,
            onMoveGemOrder = onMoveGemOrder,
            onUpdateCustomRtdbUrl = onUpdateCustomRtdbUrl,
            onLogout = onLogout,
            onDismiss = onCloseAdmin
        )
    }
}

@Composable
fun EmptyPostsState(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, FFLine, RoundedCornerShape(16.dp))
            .background(FFPanel)
            .padding(36.dp)
            .testTag("empty_posts_state"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.SearchOff,
                contentDescription = null,
                tint = FFMuted,
                modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "No posts found.",
                color = FFMuted,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
        }
    }
}

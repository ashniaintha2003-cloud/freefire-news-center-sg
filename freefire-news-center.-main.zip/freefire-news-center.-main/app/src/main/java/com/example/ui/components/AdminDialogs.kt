package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.data.model.SiteSettings
import com.example.ui.theme.FFAccent
import com.example.ui.theme.FFAccent2
import com.example.ui.theme.FFAccentGold
import com.example.ui.theme.FFBg
import com.example.ui.theme.FFDanger
import com.example.ui.theme.FFLine
import com.example.ui.theme.FFMaintenanceBg
import com.example.ui.theme.FFMaintenanceBorder
import com.example.ui.theme.FFMuted
import com.example.ui.theme.FFOk
import com.example.ui.theme.FFPanel
import com.example.ui.theme.FFPanel2
import com.example.ui.theme.FFPurpleTagText
import com.example.ui.theme.FFText
import com.example.util.ImageUtils

@Composable
fun AdminLoginDialog(
    errorMsg: String?,
    onLogin: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = FFPanel,
            border = androidx.compose.foundation.BorderStroke(1.dp, FFLine),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("login_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Admin Login",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = FFText
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(FFPanel2)
                            .testTag("login_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = FFText,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Username field
                Text(
                    text = "Username",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = FFMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    placeholder = { Text("Enter username (ASHNI)", color = FFMuted, fontSize = 13.sp) },
                    singleLine = true,
                    colors = adminTextFieldColors(),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_username")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Password field
                Text(
                    text = "Password",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = FFMuted
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    placeholder = { Text("Enter password", color = FFMuted, fontSize = 13.sp) },
                    singleLine = true,
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle password visibility",
                                tint = FFMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    },
                    colors = adminTextFieldColors(),
                    shape = RoundedCornerShape(10.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onLogin(username, password) }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password")
                )

                if (!errorMsg.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMsg,
                        color = FFDanger,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.testTag("login_error_msg")
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { onLogin(username, password) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = FFAccent,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("login_submit_btn")
                ) {
                    Text(
                        text = "LOGIN",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelDialog(
    settings: SiteSettings,
    posts: List<NewsPost>,
    banners: List<BannerItem>,
    gems: List<GemItem>,
    isFirebaseConnected: Boolean,
    actionMessage: String?,
    onSaveSettings: (String, String) -> Unit,
    onToggleMaintenance: () -> Unit,
    onAddPost: (String, String, String, String) -> Unit,
    onDeletePost: (String) -> Unit,
    onClearAllPosts: () -> Unit,
    onSaveBanner: (String?, String, String, String, Int, String) -> Unit,
    onDeleteBanner: (String) -> Unit,
    onMoveBannerOrder: (BannerItem, Int) -> Unit,
    onSaveGem: (String?, String, String, String, String, String, Int) -> Unit,
    onDeleteGem: (String) -> Unit,
    onMoveGemOrder: (GemItem, Int) -> Unit,
    onUpdateCustomRtdbUrl: (String) -> Unit,
    onLogout: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    // Website Settings State
    var siteNameInput by remember(settings.name) { mutableStateOf(settings.name) }
    var siteAboutInput by remember(settings.about) { mutableStateOf(settings.about) }

    // Add Post State
    var postTitle by remember { mutableStateOf("") }
    var postCategory by remember { mutableStateOf("news") }
    var postImageBase64 by remember { mutableStateOf("") }
    var postText by remember { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }

    // Banner State (Add/Edit)
    var editingBannerId by remember { mutableStateOf<String?>(null) }
    var bannerTitle by remember { mutableStateOf("") }
    var bannerSubtitle by remember { mutableStateOf("") }
    var bannerImageBase64 by remember { mutableStateOf("") }
    var bannerOrderInput by remember { mutableStateOf("1") }
    var bannerLinkUrl by remember { mutableStateOf("") }

    // Gem State (Add/Edit)
    var editingGemId by remember { mutableStateOf<String?>(null) }
    var gemName by remember { mutableStateOf("") }
    var gemPrice by remember { mutableStateOf("") }
    var gemImageBase64 by remember { mutableStateOf("") }
    var gemButtonLabel by remember { mutableStateOf("Top Up") }
    var gemButtonLink by remember { mutableStateOf("") }
    var gemOrderInput by remember { mutableStateOf("1") }

    // Confirmation Dialogs
    var confirmDeleteAllPosts by remember { mutableStateOf(false) }
    var postToDelete by remember { mutableStateOf<NewsPost?>(null) }
    var bannerToDelete by remember { mutableStateOf<BannerItem?>(null) }
    var gemToDelete by remember { mutableStateOf<GemItem?>(null) }

    // Photo pickers for Posts, Banners, and Gems
    val postPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val base64 = ImageUtils.uriToBase64(context, it)
            if (base64 != null) {
                postImageBase64 = base64
            }
        }
    }

    val bannerPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val base64 = ImageUtils.uriToBase64(context, it, maxDimension = 1000)
            if (base64 != null) {
                bannerImageBase64 = base64
            }
        }
    }

    val gemPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val base64 = ImageUtils.uriToBase64(context, it, maxDimension = 600)
            if (base64 != null) {
                gemImageBase64 = base64
            }
        }
    }

    val categoryOptions = listOf(
        "news" to "News",
        "update" to "Updates",
        "events" to "Events",
        "craftland" to "Craftland"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = FFPanel,
            border = androidx.compose.foundation.BorderStroke(1.dp, FFLine),
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxSize(0.94f)
                .testTag("admin_panel_modal")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Admin Control Center",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = FFText
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isFirebaseConnected) FFOk.copy(alpha = 0.2f) else FFLine)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isFirebaseConnected) "● RTDB Live" else "○ Local Mode",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFirebaseConnected) FFOk else FFMuted
                                )
                            }
                        }
                        Text(
                            text = "Manage Posts, Banners, Gems & Settings",
                            fontSize = 12.sp,
                            color = FFMuted
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(FFPanel2)
                            .testTag("admin_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Admin",
                            tint = FFText,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Action Banner
                if (!actionMessage.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(FFOk.copy(alpha = 0.15f))
                            .border(1.dp, FFOk.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = FFOk,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = actionMessage,
                                color = FFOk,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Maintenance Notice
                if (settings.maintenance) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(FFMaintenanceBg)
                            .border(1.dp, FFMaintenanceBorder, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = FFDanger,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Maintenance mode is ON. Visitors see the maintenance screen.",
                                color = Color(0xFFFECACA),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Navigation Tabs
                val tabs = listOf("Posts", "Banners", "Gems", "Settings")
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = FFPanel2,
                    contentColor = FFAccent,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = FFAccent
                        )
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, FFLine, RoundedCornerShape(10.dp))
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == index) FFAccent else FFMuted
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tab Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (selectedTab) {
                        // TAB 0: POSTS MANAGEMENT
                        0 -> {
                            // Add Post Card
                            AdminCard(title = "Add New Post") {
                                Text(text = "Title", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = postTitle,
                                    onValueChange = { postTitle = it },
                                    placeholder = { Text("Post title...", color = FFMuted, fontSize = 13.sp) },
                                    singleLine = true,
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_post_title_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // Category Dropdown
                                Text(text = "Category", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                ExposedDropdownMenuBox(
                                    expanded = categoryExpanded,
                                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                                ) {
                                    OutlinedTextField(
                                        value = categoryOptions.firstOrNull { it.first == postCategory }?.second ?: "News",
                                        onValueChange = {},
                                        readOnly = true,
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                                        colors = adminTextFieldColors(),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = categoryExpanded,
                                        onDismissRequest = { categoryExpanded = false },
                                        modifier = Modifier.background(FFPanel2)
                                    ) {
                                        categoryOptions.forEach { (catId, catLabel) ->
                                            DropdownMenuItem(
                                                text = { Text(catLabel, color = FFText) },
                                                onClick = {
                                                    postCategory = catId
                                                    categoryExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Image Upload - "Choose File" from Device Gallery
                                Text(text = "Post Image (From Gallery)", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedButton(
                                    onClick = {
                                        postPhotoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = FFPanel),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, FFAccent),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_post_choose_file_btn")
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = FFAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (postImageBase64.isBlank()) "Choose File from Device" else "Change Selected Image",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                // Image Preview Before Saving
                                if (postImageBase64.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .border(1.dp, FFLine, RoundedCornerShape(10.dp))
                                    ) {
                                        AsyncImage(
                                            model = postImageBase64,
                                            contentDescription = "Post Preview",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        IconButton(
                                            onClick = { postImageBase64 = "" },
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(6.dp)
                                                .size(28.dp)
                                                .background(Color(0xCC000000), CircleShape)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Remove Image", tint = Color.White, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Article Text
                                Text(text = "Article Text", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = postText,
                                    onValueChange = { postText = it },
                                    placeholder = { Text("Enter detailed article contents...", color = FFMuted, fontSize = 13.sp) },
                                    minLines = 4,
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_post_text_input")
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        if (postTitle.isNotBlank() && postText.isNotBlank()) {
                                            onAddPost(postTitle, postCategory, postText, postImageBase64)
                                            postTitle = ""
                                            postText = ""
                                            postImageBase64 = ""
                                        }
                                    },
                                    enabled = postTitle.isNotBlank() && postText.isNotBlank(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = FFAccent,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_add_post_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Publish Post to Firebase", fontWeight = FontWeight.Bold)
                                }
                            }

                            // Manage Posts List
                            AdminCard(title = "Existing Posts (${posts.size})") {
                                if (posts.isEmpty()) {
                                    Text("No posts published yet.", color = FFMuted, fontSize = 13.sp)
                                } else {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        posts.forEach { post ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(0xFF0C0E14))
                                                    .border(1.dp, FFLine, RoundedCornerShape(8.dp))
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = post.title,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = FFText,
                                                        maxLines = 1
                                                    )
                                                    Text(
                                                        text = post.cat.uppercase(),
                                                        color = FFPurpleTagText,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }

                                                Button(
                                                    onClick = { postToDelete = post },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = FFDanger,
                                                        contentColor = Color.White
                                                    ),
                                                    shape = RoundedCornerShape(6.dp),
                                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                    modifier = Modifier.height(32.dp).testTag("delete_post_${post.id}")
                                                ) {
                                                    Text("Delete", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Button(
                                            onClick = { confirmDeleteAllPosts = true },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = FFDanger,
                                                contentColor = Color.White
                                            ),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("admin_clear_all_posts_btn")
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Delete All Posts", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        // TAB 1: BANNERS MANAGEMENT
                        1 -> {
                            AdminCard(title = if (editingBannerId != null) "Edit Banner" else "Add New Banner") {
                                Text(text = "Banner Title", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = bannerTitle,
                                    onValueChange = { bannerTitle = it },
                                    placeholder = { Text("e.g., FREE FIRE OB48 UPDATE", color = FFMuted, fontSize = 13.sp) },
                                    singleLine = true,
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_banner_title_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(text = "Banner Subtitle", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = bannerSubtitle,
                                    onValueChange = { bannerSubtitle = it },
                                    placeholder = { Text("e.g., New ranked season & cyber abilities", color = FFMuted, fontSize = 13.sp) },
                                    singleLine = true,
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Display Order (1, 2, ...)", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = bannerOrderInput,
                                            onValueChange = { bannerOrderInput = it },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            colors = adminTextFieldColors(),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("admin_banner_order_input")
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Link / URL (Optional)", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = bannerLinkUrl,
                                            onValueChange = { bannerLinkUrl = it },
                                            placeholder = { Text("https://...", color = FFMuted, fontSize = 13.sp) },
                                            singleLine = true,
                                            colors = adminTextFieldColors(),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Choose File Button
                                Text(text = "Banner Image (Upload via Choose File)", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedButton(
                                    onClick = {
                                        bannerPhotoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = FFPanel),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, FFAccent),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_banner_choose_file_btn")
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = FFAccent, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (bannerImageBase64.isBlank()) "Choose File from Gallery" else "Change Banner Image",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                // Live Banner Preview Before Saving
                                if (bannerImageBase64.isNotBlank() || bannerTitle.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(text = "Banner Preview (5s Slideshow)", fontSize = 11.sp, color = FFAccent, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .border(1.dp, FFLine, RoundedCornerShape(12.dp))
                                    ) {
                                        if (bannerImageBase64.isNotBlank()) {
                                            AsyncImage(
                                                model = bannerImageBase64,
                                                contentDescription = "Preview",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        } else {
                                            Box(
                                                modifier = Modifier.fillMaxSize().background(Color(0xFF1B1E2B)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("Selected Banner Preview", color = FFMuted, fontSize = 12.sp)
                                            }
                                        }

                                        Column(
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .background(Color(0xAA07080C))
                                                .fillMaxWidth()
                                                .padding(8.dp)
                                        ) {
                                            Text(
                                                text = bannerTitle.ifBlank { "Banner Title" },
                                                fontWeight = FontWeight.Bold,
                                                color = FFText,
                                                fontSize = 13.sp
                                            )
                                            if (bannerSubtitle.isNotBlank()) {
                                                Text(text = bannerSubtitle, color = FFMuted, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (editingBannerId != null) {
                                        OutlinedButton(
                                            onClick = {
                                                editingBannerId = null
                                                bannerTitle = ""
                                                bannerSubtitle = ""
                                                bannerImageBase64 = ""
                                                bannerOrderInput = "1"
                                                bannerLinkUrl = ""
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Cancel", color = FFMuted)
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            if (bannerTitle.isNotBlank()) {
                                                val ord = bannerOrderInput.toIntOrNull() ?: 1
                                                onSaveBanner(
                                                    editingBannerId,
                                                    bannerTitle,
                                                    bannerSubtitle,
                                                    bannerImageBase64,
                                                    ord,
                                                    bannerLinkUrl
                                                )
                                                editingBannerId = null
                                                bannerTitle = ""
                                                bannerSubtitle = ""
                                                bannerImageBase64 = ""
                                                bannerOrderInput = (banners.size + 1).toString()
                                                bannerLinkUrl = ""
                                            }
                                        },
                                        enabled = bannerTitle.isNotBlank(),
                                        colors = ButtonDefaults.buttonColors(containerColor = FFAccent, contentColor = Color.White),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(if (editingBannerId != null) 1f else 2f).testTag("admin_save_banner_btn")
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (editingBannerId != null) "Update Banner" else "Save to Home Page", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Existing Banners List with Order Controls
                            AdminCard(title = "Existing Banners (${banners.size})") {
                                if (banners.isEmpty()) {
                                    Text("No banners added yet.", color = FFMuted, fontSize = 13.sp)
                                } else {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        banners.forEach { banner ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0xFF0C0E14))
                                                    .border(1.dp, FFLine, RoundedCornerShape(10.dp))
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // Thumbnail
                                                Box(
                                                    modifier = Modifier
                                                        .size(56.dp, 38.dp)
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(Color(0xFF1C1F2C)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (banner.image.isNotBlank()) {
                                                        AsyncImage(
                                                            model = banner.image,
                                                            contentDescription = null,
                                                            contentScale = ContentScale.Crop,
                                                            modifier = Modifier.fillMaxSize()
                                                        )
                                                    } else {
                                                        Icon(Icons.Default.Image, contentDescription = null, tint = FFMuted, modifier = Modifier.size(18.dp))
                                                    }
                                                }

                                                Spacer(modifier = Modifier.width(10.dp))

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = banner.title,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = FFText,
                                                        maxLines = 1
                                                    )
                                                    Text(
                                                        text = "Order: #${banner.order}",
                                                        color = FFAccent,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }

                                                // Reordering arrows & edit/delete buttons
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(
                                                        onClick = { onMoveBannerOrder(banner, -1) },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = FFMuted, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(
                                                        onClick = { onMoveBannerOrder(banner, 1) },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = FFMuted, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(
                                                        onClick = {
                                                            editingBannerId = banner.id
                                                            bannerTitle = banner.title
                                                            bannerSubtitle = banner.subtitle
                                                            bannerImageBase64 = banner.image
                                                            bannerOrderInput = banner.order.toString()
                                                            bannerLinkUrl = banner.linkUrl
                                                        },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.Edit, contentDescription = "Edit Banner", tint = FFAccent, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(
                                                        onClick = { bannerToDelete = banner },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete Banner", tint = FFDanger, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // TAB 2: GEMS MANAGEMENT
                        2 -> {
                            AdminCard(title = if (editingGemId != null) "Edit Gem Card" else "Add New Gem Card") {
                                Text(text = "Gem Name", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = gemName,
                                    onValueChange = { gemName = it },
                                    placeholder = { Text("e.g., 520 + 52 Bonus Diamonds", color = FFMuted, fontSize = 13.sp) },
                                    singleLine = true,
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_gem_name_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Price / Amount", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = gemPrice,
                                            onValueChange = { gemPrice = it },
                                            placeholder = { Text("e.g., $4.99", color = FFMuted, fontSize = 13.sp) },
                                            singleLine = true,
                                            colors = adminTextFieldColors(),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth().testTag("admin_gem_price_input")
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Display Order (1, 2, ...)", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = gemOrderInput,
                                            onValueChange = { gemOrderInput = it },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            colors = adminTextFieldColors(),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Button Label", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = gemButtonLabel,
                                            onValueChange = { gemButtonLabel = it },
                                            placeholder = { Text("Top Up", color = FFMuted, fontSize = 13.sp) },
                                            singleLine = true,
                                            colors = adminTextFieldColors(),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = "Button Link / URL", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = gemButtonLink,
                                            onValueChange = { gemButtonLink = it },
                                            placeholder = { Text("https://...", color = FFMuted, fontSize = 13.sp) },
                                            singleLine = true,
                                            colors = adminTextFieldColors(),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Choose File Button for Gem Image
                                Text(text = "Gem Image (Upload via Choose File)", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedButton(
                                    onClick = {
                                        gemPhotoPicker.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    colors = ButtonDefaults.outlinedButtonColors(containerColor = FFPanel),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, FFAccentGold),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_gem_choose_file_btn")
                                ) {
                                    Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = FFAccentGold, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (gemImageBase64.isBlank()) "Choose File from Gallery" else "Change Gem Image",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                // Live Gem Card Preview Before Saving
                                if (gemName.isNotBlank() || gemPrice.isNotBlank() || gemImageBase64.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(text = "Gem Card Preview", fontSize = 11.sp, color = FFAccentGold, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Box(modifier = Modifier.width(180.dp).align(Alignment.CenterHorizontally)) {
                                        GemCard(
                                            gem = GemItem(
                                                id = "preview",
                                                name = gemName.ifBlank { "Preview Diamonds" },
                                                price = gemPrice.ifBlank { "$0.00" },
                                                image = gemImageBase64,
                                                buttonLabel = gemButtonLabel.ifBlank { "Top Up" },
                                                order = gemOrderInput.toIntOrNull() ?: 1
                                            ),
                                            onActionClick = {}
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (editingGemId != null) {
                                        OutlinedButton(
                                            onClick = {
                                                editingGemId = null
                                                gemName = ""
                                                gemPrice = ""
                                                gemImageBase64 = ""
                                                gemButtonLabel = "Top Up"
                                                gemButtonLink = ""
                                                gemOrderInput = "1"
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Cancel", color = FFMuted)
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            if (gemName.isNotBlank()) {
                                                val ord = gemOrderInput.toIntOrNull() ?: 1
                                                onSaveGem(
                                                    editingGemId,
                                                    gemName,
                                                    gemPrice,
                                                    gemImageBase64,
                                                    gemButtonLabel,
                                                    gemButtonLink,
                                                    ord
                                                )
                                                editingGemId = null
                                                gemName = ""
                                                gemPrice = ""
                                                gemImageBase64 = ""
                                                gemButtonLabel = "Top Up"
                                                gemButtonLink = ""
                                                gemOrderInput = (gems.size + 1).toString()
                                            }
                                        },
                                        enabled = gemName.isNotBlank(),
                                        colors = ButtonDefaults.buttonColors(containerColor = FFAccent, contentColor = Color.White),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(if (editingGemId != null) 1f else 2f).testTag("admin_save_gem_btn")
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (editingGemId != null) "Update Gem Card" else "Save to Home Page", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // Existing Gems List
                            AdminCard(title = "Existing Gem Cards (${gems.size})") {
                                if (gems.isEmpty()) {
                                    Text("No gems added yet.", color = FFMuted, fontSize = 13.sp)
                                } else {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        gems.forEach { gem ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .background(Color(0xFF0C0E14))
                                                    .border(1.dp, FFLine, RoundedCornerShape(10.dp))
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(38.dp)
                                                        .clip(CircleShape)
                                                        .background(FFAccentGold.copy(alpha = 0.2f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (gem.image.isNotBlank()) {
                                                        AsyncImage(
                                                            model = gem.image,
                                                            contentDescription = null,
                                                            contentScale = ContentScale.Fit,
                                                            modifier = Modifier.fillMaxSize().padding(4.dp)
                                                        )
                                                    } else {
                                                        Icon(Icons.Default.Diamond, contentDescription = null, tint = FFAccentGold, modifier = Modifier.size(20.dp))
                                                    }
                                                }

                                                Spacer(modifier = Modifier.width(10.dp))

                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = gem.name,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = FFText,
                                                        maxLines = 1
                                                    )
                                                    Text(
                                                        text = "${gem.price}  •  Order #${gem.order}",
                                                        color = FFAccentGold,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }

                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(
                                                        onClick = { onMoveGemOrder(gem, -1) },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = FFMuted, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(
                                                        onClick = { onMoveGemOrder(gem, 1) },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = FFMuted, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(
                                                        onClick = {
                                                            editingGemId = gem.id
                                                            gemName = gem.name
                                                            gemPrice = gem.price
                                                            gemImageBase64 = gem.image
                                                            gemButtonLabel = gem.buttonLabel
                                                            gemButtonLink = gem.buttonLink
                                                            gemOrderInput = gem.order.toString()
                                                        },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.Edit, contentDescription = "Edit Gem", tint = FFAccent, modifier = Modifier.size(16.dp))
                                                    }
                                                    IconButton(
                                                        onClick = { gemToDelete = gem },
                                                        modifier = Modifier.size(30.dp)
                                                    ) {
                                                        Icon(Icons.Default.Delete, contentDescription = "Delete Gem", tint = FFDanger, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // TAB 3: WEBSITE SETTINGS & MAINTENANCE
                        3 -> {
                            AdminCard(title = "Website Settings") {
                                Text(text = "Website Name", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = siteNameInput,
                                    onValueChange = { siteNameInput = it },
                                    placeholder = { Text("FREE FIRE NEWS CENTER", color = FFMuted, fontSize = 13.sp) },
                                    singleLine = true,
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_site_name_input")
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(text = "About Text", fontSize = 12.sp, color = FFMuted, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = siteAboutInput,
                                    onValueChange = { siteAboutInput = it },
                                    placeholder = { Text("About description...", color = FFMuted, fontSize = 13.sp) },
                                    colors = adminTextFieldColors(),
                                    shape = RoundedCornerShape(10.dp),
                                    minLines = 3,
                                    modifier = Modifier.fillMaxWidth().testTag("admin_about_input")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { onSaveSettings(siteNameInput, siteAboutInput) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FFAccent, contentColor = Color.White),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_save_settings_btn")
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Save Settings", fontWeight = FontWeight.Bold)
                                }
                            }

                            AdminCard(title = "Maintenance Mode") {
                                Text(
                                    text = "Block visitors temporarily while updating the website.",
                                    fontSize = 13.sp,
                                    color = FFMuted
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = onToggleMaintenance,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (settings.maintenance) FFAccent else FFDanger,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("admin_maintenance_toggle_btn")
                                ) {
                                    Text(
                                        text = if (settings.maintenance) "Turn Maintenance OFF" else "Turn Maintenance ON",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onLogout,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = FFText,
                            containerColor = FFPanel2
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, FFLine),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("admin_logout_btn")
                    ) {
                        Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Logout")
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = FFPanel2, contentColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Close")
                    }
                }
            }
        }
    }

    // Confirm Single Post Delete
    if (postToDelete != null) {
        AlertDialog(
            onDismissRequest = { postToDelete = null },
            title = { Text("Delete Post?", color = FFText) },
            text = { Text("Delete '${postToDelete?.title}' from Firebase?", color = FFMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        postToDelete?.id?.let { onDeletePost(it) }
                        postToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FFDanger)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { postToDelete = null }) {
                    Text("Cancel", color = FFMuted)
                }
            },
            containerColor = FFPanel,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Confirm Single Banner Delete
    if (bannerToDelete != null) {
        AlertDialog(
            onDismissRequest = { bannerToDelete = null },
            title = { Text("Delete Banner?", color = FFText) },
            text = { Text("Delete '${bannerToDelete?.title}' from Home page slideshow?", color = FFMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        bannerToDelete?.id?.let { onDeleteBanner(it) }
                        bannerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FFDanger)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { bannerToDelete = null }) {
                    Text("Cancel", color = FFMuted)
                }
            },
            containerColor = FFPanel,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Confirm Single Gem Delete
    if (gemToDelete != null) {
        AlertDialog(
            onDismissRequest = { gemToDelete = null },
            title = { Text("Delete Gem Card?", color = FFText) },
            text = { Text("Delete '${gemToDelete?.name}' from Home page Diamond Store?", color = FFMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        gemToDelete?.id?.let { onDeleteGem(it) }
                        gemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FFDanger)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { gemToDelete = null }) {
                    Text("Cancel", color = FFMuted)
                }
            },
            containerColor = FFPanel,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Confirm Delete All Posts
    if (confirmDeleteAllPosts) {
        AlertDialog(
            onDismissRequest = { confirmDeleteAllPosts = false },
            title = { Text("Delete All Posts?", color = FFText) },
            text = { Text("This will remove all posts from Firebase and local cache.", color = FFMuted) },
            confirmButton = {
                Button(
                    onClick = {
                        onClearAllPosts()
                        confirmDeleteAllPosts = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FFDanger)
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDeleteAllPosts = false }) {
                    Text("Cancel", color = FFMuted)
                }
            },
            containerColor = FFPanel,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun AdminCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, FFLine, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = FFPanel2)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = FFText
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun adminTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = Color(0xFF0B0D13),
    unfocusedContainerColor = Color(0xFF0B0D13),
    focusedBorderColor = FFAccent,
    unfocusedBorderColor = FFLine,
    focusedTextColor = FFText,
    unfocusedTextColor = FFText
)

package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.data.model.SiteSettings
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FirebaseRealtimeManager(private val context: Context) {

    private val tag = "FirebaseRTDB"
    private var database: FirebaseDatabase? = null
    private var postsRef: DatabaseReference? = null
    private var settingsRef: DatabaseReference? = null
    private var bannersRef: DatabaseReference? = null
    private var gemsRef: DatabaseReference? = null
    private var connectedRef: DatabaseReference? = null

    private var postsListener: ValueEventListener? = null
    private var settingsListener: ValueEventListener? = null
    private var bannersListener: ValueEventListener? = null
    private var gemsListener: ValueEventListener? = null
    private var connectedListener: ValueEventListener? = null

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _remotePosts = MutableStateFlow<List<NewsPost>?>(null)
    val remotePosts: StateFlow<List<NewsPost>?> = _remotePosts.asStateFlow()

    private val _remoteSettings = MutableStateFlow<SiteSettings?>(null)
    val remoteSettings: StateFlow<SiteSettings?> = _remoteSettings.asStateFlow()

    private val _remoteBanners = MutableStateFlow<List<BannerItem>?>(null)
    val remoteBanners: StateFlow<List<BannerItem>?> = _remoteBanners.asStateFlow()

    private val _remoteGems = MutableStateFlow<List<GemItem>?>(null)
    val remoteGems: StateFlow<List<GemItem>?> = _remoteGems.asStateFlow()

    private val _connectionStatusMessage = MutableStateFlow("Initializing Firebase...")
    val connectionStatusMessage: StateFlow<String> = _connectionStatusMessage.asStateFlow()

    init {
        initializeFirebase(null)
    }

    fun initializeFirebase(customUrl: String?) {
        try {
            ensureFirebaseApp()

            database = if (!customUrl.isNullOrBlank()) {
                FirebaseDatabase.getInstance(customUrl.trim())
            } else {
                try {
                    FirebaseDatabase.getInstance()
                } catch (e: Exception) {
                    Log.w(tag, "Default instance failed, using default RTDB fallback URL: ${e.message}")
                    FirebaseDatabase.getInstance("https://free-fire-news-center-default-rtdb.firebaseio.com")
                }
            }

            database?.let { db ->
                try {
                    db.setPersistenceEnabled(true)
                } catch (ignored: Exception) {}

                detachListeners()

                postsRef = db.getReference("posts")
                settingsRef = db.getReference("settings")
                bannersRef = db.getReference("banners")
                gemsRef = db.getReference("gems")
                connectedRef = db.getReference(".info/connected")

                attachListeners()
                _connectionStatusMessage.value = "Connected to Firebase Realtime Database"
            }
        } catch (e: Exception) {
            Log.e(tag, "Failed to initialize Firebase Realtime Database: ${e.message}", e)
            _connectionStatusMessage.value = "Firebase Offline: ${e.localizedMessage ?: "Unknown error"}"
            _isConnected.value = false
        }
    }

    private fun ensureFirebaseApp() {
        if (FirebaseApp.getApps(context).isEmpty()) {
            val options = FirebaseOptions.Builder()
                .setApplicationId("com.aistudio.freefirenews.ffncapp")
                .setApiKey("AIzaSyDevPreviewFakeKeyForRealtimeDbFallback123")
                .setDatabaseUrl("https://free-fire-news-center-default-rtdb.firebaseio.com")
                .setProjectId("freefirenews-ffncapp")
                .build()
            FirebaseApp.initializeApp(context, options)
            Log.d(tag, "Initialized default FirebaseApp with options")
        }
    }

    private fun attachListeners() {
        // Connected listener
        connectedListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                _isConnected.value = connected
            }

            override fun onCancelled(error: DatabaseError) {
                _isConnected.value = false
            }
        }
        connectedRef?.addValueEventListener(connectedListener!!)

        // Posts listener
        postsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<NewsPost>()
                for (child in snapshot.children) {
                    try {
                        val map = child.value as? Map<*, *>
                        if (map != null) {
                            @Suppress("UNCHECKED_CAST")
                            val post = NewsPost.fromMap(map as Map<String, Any?>)
                            list.add(post)
                        }
                    } catch (e: Exception) {
                        Log.e(tag, "Error parsing post child: ${child.key}", e)
                    }
                }
                _remotePosts.value = list.sortedByDescending { it.timestamp }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(tag, "Posts listener cancelled: ${error.message}")
            }
        }
        postsRef?.addValueEventListener(postsListener!!)

        // Settings listener
        settingsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val map = snapshot.value as? Map<*, *>
                if (map != null) {
                    @Suppress("UNCHECKED_CAST")
                    val settings = SiteSettings.fromMap(map as Map<String, Any?>)
                    _remoteSettings.value = settings
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(tag, "Settings listener cancelled: ${error.message}")
            }
        }
        settingsRef?.addValueEventListener(settingsListener!!)

        // Banners listener
        bannersListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<BannerItem>()
                for (child in snapshot.children) {
                    try {
                        val map = child.value as? Map<*, *>
                        if (map != null) {
                            @Suppress("UNCHECKED_CAST")
                            val banner = BannerItem.fromMap(map as Map<String, Any?>)
                            list.add(banner)
                        }
                    } catch (e: Exception) {
                        Log.e(tag, "Error parsing banner child: ${child.key}", e)
                    }
                }
                _remoteBanners.value = list.sortedWith(compareBy({ it.order }, { -it.timestamp }))
                Log.d(tag, "Received ${list.size} banners in real time from Firebase")
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(tag, "Banners listener cancelled: ${error.message}")
            }
        }
        bannersRef?.addValueEventListener(bannersListener!!)

        // Gems listener
        gemsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<GemItem>()
                for (child in snapshot.children) {
                    try {
                        val map = child.value as? Map<*, *>
                        if (map != null) {
                            @Suppress("UNCHECKED_CAST")
                            val gem = GemItem.fromMap(map as Map<String, Any?>)
                            list.add(gem)
                        }
                    } catch (e: Exception) {
                        Log.e(tag, "Error parsing gem child: ${child.key}", e)
                    }
                }
                _remoteGems.value = list.sortedWith(compareBy({ it.order }, { -it.timestamp }))
                Log.d(tag, "Received ${list.size} gems in real time from Firebase")
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(tag, "Gems listener cancelled: ${error.message}")
            }
        }
        gemsRef?.addValueEventListener(gemsListener!!)
    }

    private fun detachListeners() {
        postsListener?.let { postsRef?.removeEventListener(it) }
        settingsListener?.let { settingsRef?.removeEventListener(it) }
        bannersListener?.let { bannersRef?.removeEventListener(it) }
        gemsListener?.let { gemsRef?.removeEventListener(it) }
        connectedListener?.let { connectedRef?.removeEventListener(it) }
    }

    // Post operations
    fun addOrUpdatePost(post: NewsPost, onComplete: ((Boolean, String?) -> Unit)? = null) {
        val ref = postsRef?.child(post.id)
        if (ref != null) {
            ref.setValue(post.toMap())
                .addOnSuccessListener { onComplete?.invoke(true, null) }
                .addOnFailureListener { onComplete?.invoke(false, it.message) }
        } else {
            onComplete?.invoke(false, "Firebase Realtime Database not connected")
        }
    }

    fun deletePost(postId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        postsRef?.child(postId)?.removeValue()
            ?.addOnSuccessListener { onComplete?.invoke(true, null) }
            ?.addOnFailureListener { onComplete?.invoke(false, it.message) }
    }

    fun clearAllPosts(onComplete: ((Boolean, String?) -> Unit)? = null) {
        postsRef?.removeValue()
            ?.addOnSuccessListener { onComplete?.invoke(true, null) }
            ?.addOnFailureListener { onComplete?.invoke(false, it.message) }
    }

    // Settings operations
    fun updateSettings(settings: SiteSettings, onComplete: ((Boolean, String?) -> Unit)? = null) {
        settingsRef?.setValue(settings.toMap())
            ?.addOnSuccessListener { onComplete?.invoke(true, null) }
            ?.addOnFailureListener { onComplete?.invoke(false, it.message) }
    }

    fun setMaintenance(enabled: Boolean, onComplete: ((Boolean, String?) -> Unit)? = null) {
        settingsRef?.child("maintenance")?.setValue(enabled)
            ?.addOnSuccessListener { onComplete?.invoke(true, null) }
            ?.addOnFailureListener { onComplete?.invoke(false, it.message) }
    }

    // Banner operations
    fun addOrUpdateBanner(banner: BannerItem, onComplete: ((Boolean, String?) -> Unit)? = null) {
        val ref = bannersRef?.child(banner.id)
        if (ref != null) {
            ref.setValue(banner.toMap())
                .addOnSuccessListener { onComplete?.invoke(true, null) }
                .addOnFailureListener { onComplete?.invoke(false, it.message) }
        } else {
            onComplete?.invoke(false, "Firebase Realtime Database not connected")
        }
    }

    fun deleteBanner(bannerId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        bannersRef?.child(bannerId)?.removeValue()
            ?.addOnSuccessListener { onComplete?.invoke(true, null) }
            ?.addOnFailureListener { onComplete?.invoke(false, it.message) }
    }

    // Gem operations
    fun addOrUpdateGem(gem: GemItem, onComplete: ((Boolean, String?) -> Unit)? = null) {
        val ref = gemsRef?.child(gem.id)
        if (ref != null) {
            ref.setValue(gem.toMap())
                .addOnSuccessListener { onComplete?.invoke(true, null) }
                .addOnFailureListener { onComplete?.invoke(false, it.message) }
        } else {
            onComplete?.invoke(false, "Firebase Realtime Database not connected")
        }
    }

    fun deleteGem(gemId: String, onComplete: ((Boolean, String?) -> Unit)? = null) {
        gemsRef?.child(gemId)?.removeValue()
            ?.addOnSuccessListener { onComplete?.invoke(true, null) }
            ?.addOnFailureListener { onComplete?.invoke(false, it.message) }
    }

    fun seedInitialDataIfEmpty(
        posts: List<NewsPost>,
        defaultSettings: SiteSettings,
        defaultBanners: List<BannerItem>,
        defaultGems: List<GemItem>
    ) {
        postsRef?.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists() || snapshot.childrenCount == 0L) {
                    val map = mutableMapOf<String, Any>()
                    posts.forEach { post -> map[post.id] = post.toMap() }
                    postsRef?.setValue(map)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        settingsRef?.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    settingsRef?.setValue(defaultSettings.toMap())
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        bannersRef?.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists() || snapshot.childrenCount == 0L) {
                    val map = mutableMapOf<String, Any>()
                    defaultBanners.forEach { banner -> map[banner.id] = banner.toMap() }
                    bannersRef?.setValue(map)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        gemsRef?.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists() || snapshot.childrenCount == 0L) {
                    val map = mutableMapOf<String, Any>()
                    defaultGems.forEach { gem -> map[gem.id] = gem.toMap() }
                    gemsRef?.setValue(map)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }
}

package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.BannerItem
import com.example.data.model.GemItem
import com.example.data.model.NewsPost
import com.example.data.model.SiteSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Free Fire News", appName)
    }

    @Test
    fun `default news posts are populated`() {
        val posts = NewsPost.DEFAULT_POSTS
        assertEquals(6, posts.size)
        assertTrue(posts.any { it.cat == "news" })
        assertTrue(posts.any { it.cat == "update" })
        assertTrue(posts.any { it.cat == "events" })
        assertTrue(posts.any { it.cat == "craftland" })
    }

    @Test
    fun `default banners and gems are populated`() {
        val banners = BannerItem.DEFAULT_BANNERS
        val gems = GemItem.DEFAULT_GEMS
        assertEquals(3, banners.size)
        assertEquals(6, gems.size)
    }

    @Test
    fun `post toMap and fromMap serialization`() {
        val post = NewsPost(
            id = "test-1",
            cat = "update",
            title = "Test Update Title",
            text = "Test Update Text",
            image = "https://example.com/test.jpg"
        )
        val map = post.toMap()
        val restored = NewsPost.fromMap(map)
        assertEquals(post.id, restored.id)
        assertEquals(post.cat, restored.cat)
        assertEquals(post.title, restored.title)
        assertEquals(post.text, restored.text)
        assertEquals(post.image, restored.image)
    }

    @Test
    fun `banner toMap and fromMap serialization`() {
        val banner = BannerItem(
            id = "b-1",
            title = "OB48 Battle Banner",
            subtitle = "New ranked changes",
            image = "data:image/jpeg;base64,...",
            order = 2,
            linkUrl = "https://example.com"
        )
        val map = banner.toMap()
        val restored = BannerItem.fromMap(map)
        assertEquals(banner.id, restored.id)
        assertEquals(banner.title, restored.title)
        assertEquals(banner.subtitle, restored.subtitle)
        assertEquals(banner.image, restored.image)
        assertEquals(2, restored.order)
        assertEquals(banner.linkUrl, restored.linkUrl)
    }

    @Test
    fun `gem toMap and fromMap serialization`() {
        val gem = GemItem(
            id = "gem-1",
            name = "100 + 10 Diamonds",
            price = "$0.99",
            image = "data:image/jpeg;base64,...",
            buttonLabel = "Top Up",
            buttonLink = "https://example.com",
            order = 1
        )
        val map = gem.toMap()
        val restored = GemItem.fromMap(map)
        assertEquals(gem.id, restored.id)
        assertEquals(gem.name, restored.name)
        assertEquals(gem.price, restored.price)
        assertEquals(gem.buttonLabel, restored.buttonLabel)
        assertEquals(1, restored.order)
    }

    @Test
    fun `settings toMap and fromMap serialization`() {
        val settings = SiteSettings(
            name = "TEST FREE FIRE",
            about = "Custom about text",
            maintenance = true
        )
        val map = settings.toMap()
        val restored = SiteSettings.fromMap(map)
        assertEquals(settings.name, restored.name)
        assertEquals(settings.about, restored.about)
        assertEquals(true, restored.maintenance)
    }
}
